# Architecture & Evolution

## 🏗️ Solution Evolution

### ❌ BEFORE (Separate Scripts)
```
generate_variations.py (offline mode)      generate_variations.py (AI mode)
         ↓                                            ↓
    20-30 variations              +        30-40 variations
    (rule-based)                  +        (AI-based)
    <1 second                      +        2-5 seconds
    
Problem: Need to run twice to get complete picture
```

### ✅ AFTER (Unified Pipeline)
```
INPUT: "Julius bear pvt limited ag"
         ↓
┌─────────────────────────────────────────────┐
│        entity_search.py (3 modes)           │
├─────────────────────────────────────────────┤
│                                             │
│  OFFLINE MODE (instant)                    │
│  ├─ Rule-based variations (20)             │
│  ├─ Time: <1 second                        │
│  └─ No API needed                          │
│                                             │
│  AI MODE (creative)                        │
│  ├─ AI-generated variations (40)           │
│  ├─ Time: 2-5 seconds                      │
│  └─ Needs API key                          │
│                                             │
│  HYBRID MODE ⭐ (best)                     │
│  ├─ Step 1: Offline → 20 variations        │
│  ├─ Step 2: AI enhancement → +20 variations│
│  ├─ Step 3: Merge + deduplicate            │
│  ├─ Total: 40-60 unique variations         │
│  └─ Time: 2-5 seconds (same as AI alone!)  │
│                                             │
└─────────────────────────────────────────────┘
         ↓
OUTPUT: 40-60 sorted variations + scores
```

---

## 📊 Mode Comparison Matrix

```
┌──────────────┬───────────┬────────┬─────────────┬────────────┐
│ Aspect       │ Offline   │ AI     │ Hybrid ⭐   │ Compare    │
├──────────────┼───────────┼────────┼─────────────┼────────────┤
│ Speed        │ ⚡ Instant│ 🧠 2-5s│ 🚀 2-5s     │ ⚡ <1ms    │
│ Variations   │ 8-20      │ 30-40  │ 40-60       │ N/A        │
│ Quality      │ ★★★☆☆    │ ★★★★★ │ ★★★★★      │ ★★★★★     │
│ API Needed   │ ❌ No     │ ✅ Yes │ ✅ Yes      │ ❌ No      │
│ Cost         │ $0        │ ~$0.01 │ ~$0.01      │ $0         │
│ Use Case     │ Quick     │ Creative│ Production │ Comparison │
└──────────────┴───────────┴────────┴─────────────┴────────────┘
```

---

## 🎯 Decision Tree

```
START: Want entity variations?
  │
  ├─ YES ─→ Use entity_search.py
  │         │
  │         ├─ Need results in <1 second?
  │         │  ├─ YES ─→ Use "offline" mode ⚡
  │         │  └─ NO ──→ Continue...
  │         │
  │         ├─ Have API key?
  │         │  ├─ NO ──→ Use "offline" mode
  │         │  └─ YES ─→ Continue...
  │         │
  │         └─ Want BEST results?
  │            ├─ YES ─→ Use "hybrid" mode ⭐ (RECOMMENDED)
  │            └─ NO ──→ Use "ai" mode
  │
  └─ NO ──→ Want to compare 2 entities?
            └─ YES ─→ Use compare_entities.py
```

---

## 🔄 Hybrid Mode Pipeline

```
                    entity_search.py (hybrid)
                            │
                    ┌───────┴───────┐
                    ▼               ▼
        ┌─────────────────┐  ┌──────────────────┐
        │  OFFLINE MODE   │  │  Available if    │
        │ (always runs)   │  │  API key set     │
        └────────┬────────┘  └──────────┬───────┘
                 │                      │
        Generate 15-20 base    If available, enhance
        variations using:       with AI:
        ├─ Abbreviations        ├─ Take base variations
        ├─ Case changes         ├─ Send to Claude
        ├─ Word reordering      ├─ "Generate 20 more based
        ├─ Acronyms             │  on these patterns"
        ├─ Suffixes             └─ Get 20+ new variations
        └─ Spelling
                 │                      │
                 │         ┌────────────┘
                 │         │
                 └────┬────┘
                      ▼
        ┌────────────────────────────────┐
        │    MERGE & DEDUPLICATE         │
        │ ├─ Combine all variations      │
        │ ├─ Remove duplicates           │
        │ └─ Score each one (60/40 split)│
        └────────────┬───────────────────┘
                     ▼
        ┌────────────────────────────────┐
        │       SORT BY SCORE            │
        │ └─ Highest to lowest           │
        └────────────┬───────────────────┘
                     ▼
        ┌────────────────────────────────┐
        │         OUTPUT                 │
        │ ├─ Console table (top 25)      │
        │ ├─ JSON file (all results)     │
        │ └─ CSV file (all results)      │
        └────────────────────────────────┘
```

---

## 📊 Score Calculation

```
For each variation:

Linguistic Score = Levenshtein Distance Match
  (character-level similarity, 0-100%)
  
Phonetic Score = Soundex Match
  (sounds-like similarity, 0 or 100%)

Combined Score = (Linguistic × 0.6) + (Phonetic × 0.4)
  (weighted average, 0-100%)

Example:
  Original: "Julius bear pvt limited ag"
  Variant:  "julius bear private limited"
  
  Linguistic: 74% (7 edits from 15 max)
  Phonetic:   100% (same Soundex code: J421)
  Combined:   (74 × 0.6) + (100 × 0.4) = 84%
  
  Verdict: STRONG MATCH ✓
```

---

## 🎯 Two Scripts, Two Purposes

### Script 1: `entity_search.py`
**Purpose:** Generate all variations + scores

**Input:** 1 entity name
```bash
python entity_search.py "Julius bear pvt limited ag"
```

**Output:** 40-60 variations sorted by score
```
1. julius bear pvt limited ag          100%
2. julius bear private limited ag      88%
3. julius bear pvt ltd                 77%
...
```

**Modes:**
- `offline` → Instant, no API
- `ai` → Creative, needs API  
- `hybrid` → Best, needs API

---

### Script 2: `compare_entities.py`
**Purpose:** Compare 2 entities + get score

**Input:** 2 entity names
```bash
python compare_entities.py "Entity A" "Entity B"
```

**Output:** Similarity score + verdict
```
Linguistic: 74%
Phonetic:   100%
Combined:   84%
Verdict:    STRONG MATCH ✓
```

**Features:**
- Detailed analysis
- Soundex codes shown
- Match category
- JSON export

---

## 🚀 Real-World Scenarios

### Scenario 1: Quick Duplicate Check
```
Time budget: < 1 second
Solution: entity_search.py + offline mode

$ python entity_search.py "Company A" offline
Results: 8 variations in <100ms
```

### Scenario 2: Complete Variation Coverage
```
Time budget: 2-5 seconds allowed
Solution: entity_search.py + hybrid mode

$ python entity_search.py "Company A" hybrid
Results: 40-60 variations in 2-5 seconds
(offline variations + AI enhancement)
```

### Scenario 3: Verify Specific Match
```
Need to verify: "Company A" == "Company B"?
Solution: compare_entities.py

$ python compare_entities.py "Company A" "Company B"
Results: 
  Score: 84%
  Verdict: STRONG MATCH
  Time: <1ms
```

### Scenario 4: Master Data Sync
```
Sync master list against operational DB
Solution: entity_search.py (offline) for speed + compare_entities.py

1. Generate variations of all master entities (offline, instant)
2. For each operational entity, find best match
3. If score > 75%, mark as match
4. Manual review for borderline cases
```

---

## 💡 Why Hybrid is Superior

### Offline Only
- ✅ Fast (instant)
- ✅ No API
- ❌ Limited variations (8-20)
- ❌ Misses patterns

### AI Only
- ✅ Creative (40 variations)
- ✅ Diverse
- ❌ Takes 2-5 seconds
- ❌ Needs API key
- ❌ Might miss obvious patterns

### Hybrid (Best!) 🌟
- ✅ Fast baseline (offline instant)
- ✅ Creative enhancement (AI)
- ✅ Complete coverage (40-60)
- ✅ Smart deduplication
- ✅ Only 2-5 seconds (same as AI!)
- ✅ Better pattern matching

**Result:** Hybrid gets you the BEST of both worlds in same time as AI alone!

---

## 📈 Performance Characteristics

```
╔═══════════════════════════════════════════════════════════╗
║              PERFORMANCE ANALYSIS                         ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║ Input size: "Julius bear pvt limited ag" (27 chars)      ║
║                                                           ║
║ OFFLINE MODE:                                            ║
║   Time:       <100ms                                     ║
║   API calls:  0                                          ║
║   Variations: 15-20                                      ║
║   Quality:    Good (rule-based)                          ║
║                                                           ║
║ AI MODE:                                                 ║
║   Time:       2-5 seconds                                ║
║   API calls:  1                                          ║
║   Variations: 30-40                                      ║
║   Quality:    Excellent (AI-generated)                   ║
║                                                           ║
║ HYBRID MODE:                                             ║
║   Time:       2-5 seconds (same!)                        ║
║   API calls:  1                                          ║
║   Variations: 40-60 (more!)                              ║
║   Quality:    Best (offline + AI)                        ║
║                                                           ║
║ COMPARE MODE:                                            ║
║   Time:       <1ms                                       ║
║   API calls:  0                                          ║
║   Quality:    Excellent (pure math)                      ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
```

---

## 🎓 Algorithm Flow

```
INPUT: Original Entity Name
         │
         ▼
    ╔═════════════════════╗
    ║  OFFLINE GENERATOR  ║  (Runs in <100ms)
    ╠═════════════════════╣
    ║ 1. Case variations  ║
    ║ 2. Abbreviations    ║
    ║ 3. Suffix changes   ║
    ║ 4. Word ordering    ║
    ║ 5. Acronyms         ║
    ║ 6. Spelling fixes   ║
    ╚──────────┬──────────╝
               │
               ▼
    [20-30 base variations]
               │
               ▼ (if hybrid mode + API available)
    ╔═════════════════════╗
    ║  AI ENHANCEMENT     ║  (Runs in 2-5 seconds)
    ╠═════════════════════╣
    ║ Claude receives:    ║
    ║ 1. Original entity  ║
    ║ 2. Base variations  ║
    ║ 3. Request:         ║
    ║    "Generate 20+    ║
    ║     more based on   ║
    ║     these patterns" ║
    ╚──────────┬──────────╝
               │
               ▼
    [20-40 additional variations]
               │
               ▼
    ╔═════════════════════╗
    ║  MERGE & DEDUPLICATE║  (Runs in <100ms)
    ╠═════════════════════╣
    ║ - Combine all       ║
    ║ - Remove duplicates ║
    ║ - Case normalization║
    ╚──────────┬──────────╝
               │
               ▼
    ╔═════════════════════╗
    ║  SCORE ALL          ║  (Runs in <100ms)
    ╠═════════════════════╣
    ║ For each variant:   ║
    ║ 1. Linguistic score ║
    ║ 2. Phonetic score   ║
    ║ 3. Combined score   ║
    ║ 4. Sort by score    ║
    ╚──────────┬──────────╝
               │
               ▼
    [40-60 scored variations sorted]
               │
               ▼
    OUTPUT:
    ├─ Console table
    ├─ JSON file
    └─ CSV file
```

---

## ✨ Key Innovations

### Innovation 1: Hybrid Pipeline
**Before:** Run offline OR AI
**After:** Run offline THEN AI in one pipeline
**Benefit:** Best of both + same time as AI

### Innovation 2: Smart Deduplication
**Before:** Might miss near-duplicates
**After:** Case-insensitive deduplication
**Benefit:** No wasted rows

### Innovation 3: Three Modes, One Script
**Before:** Separate scripts
**After:** Single script with mode selection
**Benefit:** Simpler, unified interface

### Innovation 4: Unified Scoring
**Before:** Ad-hoc calculations
**After:** Consistent 60/40 weighted scoring
**Benefit:** Reliable, reproducible results

---

## 🎯 Summary

| Feature | Separate Scripts | Unified Solution |
|---------|-----------------|-----------------|
| Scripts | 2 (generate + compare) | 2 (entity_search + compare) |
| Modes | 2 (offline + AI) | 3 (offline + AI + **hybrid**) |
| Best results | Run both twice | Run hybrid once ⭐ |
| Speed | Offline instant or AI 2-5s | Hybrid 2-5s (best!) |
| Code reuse | Minimal | Maximum |
| User experience | Multiple options | Clear recommendation |

**Recommendation:** Always use `hybrid` mode for best results!

```bash
python entity_search.py "Your Entity" hybrid
```

One command. 40-60 variations. 2-5 seconds. Best results. ✨
