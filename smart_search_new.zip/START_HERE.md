# 🎯 START HERE

## What You Need (2 Files)

You only need **2 Python scripts**:

### 1. `entity_search.py` ⭐ MAIN SCRIPT
Generate all combinations of an entity name with similarity scores

### 2. `compare_entities.py`
Compare 2 entities and get their similarity score

---

## ⚡ 30-Second Quick Start

### Step 1: Install
```bash
pip install anthropic
```

### Step 2: Generate Variations
```bash
# Recommended (hybrid mode)
python entity_search.py "Julius bear pvt limited ag"

# Or just offline (instant, no API)
python entity_search.py "Julius bear pvt limited ag" offline
```

### Step 3: Compare Two Entities
```bash
python compare_entities.py "Entity 1" "Entity 2"
```

Done! ✨

---

## 📖 Documentation Files (Read These)

| File | Purpose | Read When |
|------|---------|-----------|
| **README_FINAL.md** | Quick overview (start here) | First time using |
| **UNIFIED_GUIDE.md** | Detailed guide to all 3 modes | Want to understand modes |
| **USAGE.md** | Real-world examples | Need examples |
| **ARCHITECTURE.md** | How it works internally | Want to understand design |

---

## 🐍 Python Scripts (Use These)

### Scripts You Need
1. **`entity_search.py`** - Generate variations (hybrid/offline/ai modes)
2. **`compare_entities.py`** - Compare 2 entities

### Scripts You Don't Need (Old/Deprecated)
- `generate_variations.py` - Replaced by `entity_search.py`
- `standalone.py` - Original version, use `entity_search.py` instead
- `server.py` - MCP version, not needed for basic use
- Other files - Ignore, these are previous iterations

---

## 🚀 Three Simple Commands

### Command 1: Generate Variations (Hybrid Mode - RECOMMENDED)
```bash
python entity_search.py "Your Entity Name" hybrid
```
Result: 40-60 variations in 2-5 seconds with scores

### Command 2: Generate Variations (Offline Mode - Instant)
```bash
python entity_search.py "Your Entity Name" offline
```
Result: 8-20 variations in <1 second with scores

### Command 3: Compare Two Entities
```bash
python compare_entities.py "Entity A" "Entity B"
```
Result: Similarity score + verdict in <1ms

---

## 📊 What You Get

### From `entity_search.py`:

**Console Output:**
```
Entity Name Variations: Julius bear pvt limited ag
Mode: HYBRID

Total variations: 32
Average score: 58%
Top match: 100%

#    Variant                           Linguistic   Phonetic   Combined    
1    julius bear pvt limited ag        100%         100%       100%        
2    julius bear private limited ag    92%          80%        88%         
3    julius bear pvt ltd               87%          60%        77%         
...
```

**JSON File:** `entity_search_<name>_<mode>.json`
- All variations
- All scores
- Metadata

**CSV File:** `entity_search_<name>_<mode>.csv`
- Spreadsheet-ready
- All scores
- Easy to filter

### From `compare_entities.py`:

**Console Output:**
```
ENTITY COMPARISON RESULT
Entity 1: Julius bear pvt limited ag
Entity 2: julius bear private limited

Linguistic Score:   74%
Phonetic Score:    100%
Combined Score:     84%

Match Category: STRONG MATCH
```

**JSON File:** `comparison_result.json`
- Detailed analysis
- Soundex codes
- Match category

---

## 📋 Which Mode to Use?

```
┌─ Need results in <1 second? 
│  └─ YES → python entity_search.py "Name" offline
│
└─ Have time and want BEST results?
   └─ YES → python entity_search.py "Name" hybrid ⭐
```

### Three Modes Explained

| Mode | Speed | Variations | When to Use |
|------|-------|-----------|-------------|
| `offline` | ⚡ Instant | 8-20 | Quick check, no API |
| `ai` | 🧠 2-5s | 30-40 | Pure AI creativity |
| `hybrid` | 🚀 2-5s | 40-60 | **RECOMMENDED** ⭐ |

---

## 🎯 Real Examples

### Example 1: Quick Duplicate Detection
```bash
# Offline mode - instant check
python entity_search.py "Acme Corporation" offline

# Get results in <1 second
# Then check if "Acme Corp" matches any variation
```

### Example 2: Complete Variation Analysis
```bash
# Hybrid mode - best results
python entity_search.py "Microsoft Corp" hybrid

# Get 40-60 variations in 2-5 seconds
# Check the JSON file for all variations
```

### Example 3: Verify Specific Match
```bash
# Compare mode - instant
python compare_entities.py "Apple Inc" "Apple Corporation"

# Get: 86% combined score
# Verdict: STRONG MATCH
```

---

## 📊 Score Interpretation

| Score | Meaning |
|-------|---------|
| **80-100%** | Likely same entity ✓✓✓ |
| **60-79%** | Probably same, verify ✓✓ |
| **40-59%** | Might be related ✓ |
| **0-39%** | Different entities ✗ |

---

## ✅ Checklist

Before you start:
- [ ] Python 3.6+ installed
- [ ] `pip install anthropic` run
- [ ] `entity_search.py` downloaded
- [ ] `compare_entities.py` downloaded

Optional (for hybrid/ai modes):
- [ ] `export ANTHROPIC_API_KEY="sk-..."` set

---

## 🚀 Common Use Cases

### Use Case 1: Find Duplicate Records
```bash
python entity_search.py "Company Name" offline
# Get base variations instantly
# Compare your DB records against these
```

### Use Case 2: Verify Company Names
```bash
python compare_entities.py "Company from DB" "Company from List"
# Get score - if >75% they're likely same
```

### Use Case 3: Generate All Variations
```bash
python entity_search.py "Company Name" hybrid
# Get 40-60 variations
# Use to search in master data
```

### Use Case 4: Data Quality Check
```bash
python compare_entities.py "Oracle Database" "Orale Database"
# Score 95% → Typo detected!
```

---

## 📂 File Organization

### What You Actually Use
```
/your-folder/
├── entity_search.py          ← MAIN SCRIPT
├── compare_entities.py        ← COMPARISON SCRIPT
└── README_FINAL.md           ← READ THIS FIRST
```

### Documentation (Read These)
```
START_HERE.md                 ← You are here
README_FINAL.md               ← Overview
UNIFIED_GUIDE.md              ← Detailed modes
USAGE.md                      ← Examples
ARCHITECTURE.md               ← How it works
```

### Old Files (Ignore These)
```
generate_variations.py         (use entity_search.py instead)
standalone.py                 (old version)
server.py                      (MCP version, not needed)
examples.py                    (old examples)
tests.py                       (for testing)
```

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Run: `pip install anthropic` |
| `ANTHROPIC_API_KEY not set` | Run: `export ANTHROPIC_API_KEY="sk-..."` |
| No results | Entity name should be 3+ characters |
| File not found | Make sure you're in the right directory |

---

## 🎓 30-Second Understanding

### What does `entity_search.py` do?
```
You give it 1 entity name
↓
It generates 40-60 variations
↓
It scores each one (0-100%)
↓
You get JSON + CSV + console output
```

### What does `compare_entities.py` do?
```
You give it 2 entity names
↓
It calculates similarity score
↓
It gives you a verdict
↓
You know if they're the same entity
```

---

## 💡 Pro Tips

1. **Offline mode is instant** - Use when you need speed
2. **Hybrid mode is best** - Use when you want complete results
3. **Export to JSON** - For programmatic access
4. **Score >75% is safe** - Usually means same entity
5. **Always verify manually** - AI/algorithms aren't perfect

---

## 🔄 Next Steps

1. **Download:** `entity_search.py` and `compare_entities.py`
2. **Install:** `pip install anthropic`
3. **Try it:** `python entity_search.py "Your Company"`
4. **Compare:** `python compare_entities.py "Company A" "Company B"`
5. **Read more:** Open `README_FINAL.md`

---

## 📞 Quick Reference

### Script 1: Generate Variations
```bash
python entity_search.py "<entity_name>" [offline|ai|hybrid]
```

### Script 2: Compare Entities  
```bash
python compare_entities.py "<entity1>" "<entity2>"
```

### Modes
- `offline` → Instant, rule-based, no API
- `ai` → 2-5s, AI-creative, needs API
- `hybrid` → 2-5s, best of both, needs API

---

## ✨ That's It!

You have everything you need. Two scripts. Three modes. One solution.

**Get started:**
```bash
pip install anthropic
python entity_search.py "Julius bear pvt limited ag" hybrid
```

**Enjoy!** 🚀

---

For detailed documentation, see:
- `README_FINAL.md` - Overview and examples
- `UNIFIED_GUIDE.md` - Detailed mode guide
- `USAGE.md` - More examples
- `ARCHITECTURE.md` - How it works
