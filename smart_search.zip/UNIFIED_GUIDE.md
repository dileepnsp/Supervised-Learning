# Entity Name Search - Unified Guide

## 🎯 One Script, Three Modes

A single Python script (`entity_search.py`) with three modes:

| Mode | Speed | Quality | Use Case |
|------|-------|---------|----------|
| **Offline** | ⚡ Instant | Good | Quick checks, no API |
| **AI** | 🧠 2-5s | Excellent | Creative variations |
| **Hybrid** ⭐ | 🚀 2-5s | Best | Production use |

---

## 🚀 Quick Start

### Installation
```bash
pip install anthropic
```

### Basic Usage
```bash
# Default mode (Hybrid - RECOMMENDED)
python entity_search.py "Julius bear pvt limited ag"

# Offline mode (instant, no API)
python entity_search.py "Julius bear pvt limited ag" offline

# AI mode (creative only)
python entity_search.py "Julius bear pvt limited ag" ai

# Hybrid mode (offline + AI enhancement)
python entity_search.py "Julius bear pvt limited ag" hybrid
```

---

## 📊 How Hybrid Mode Works (RECOMMENDED)

```
Input: "Julius bear pvt limited ag"
        ↓
    [STEP 1] OFFLINE MODE (instant)
    ├─ Generate 20-30 base variations using rules
    ├─ Examples: "julius bear private limited", "julius bear pvt ltd", etc.
    ├─ Time: < 1 second
    └─ Output: List of variations
        ↓
    [STEP 2] AI ENHANCEMENT (2-5 seconds)
    ├─ Send offline variations to Claude
    ├─ Claude: "Based on these, generate 20 MORE creative variations"
    ├─ Examples: phonetic variations, regional names, etc.
    └─ Output: Additional AI-generated variations
        ↓
    [STEP 3] MERGE & DEDUPLICATE
    ├─ Combine offline + AI variations
    ├─ Remove duplicates (case-insensitive)
    ├─ Score each one
    └─ Return final sorted list
        ↓
    Output: 40-50 unique variations + scores
```

### Why Hybrid is Best
✅ Fast (offline gets ~20 variations instantly)
✅ Creative (AI adds unique variations)
✅ Diverse (both patterns covered)
✅ Complete (offline baseline + AI enhancement)

---

## 📈 Example Output

```bash
$ python entity_search.py "Julius bear pvt limited ag" hybrid

[1/3] Generating offline variations...
      Generated 15 offline variations
[2/3] Enhancing with AI...
      Generated 20 AI variations
[3/3] Merging and deduplicating...
      Final count: 32 unique variations

============================================================
Entity Name Variations: Julius bear pvt limited ag
Mode: HYBRID
============================================================

Total variations: 32
Average score: 58%
Top match: 100%

#    Variant                                    Linguistic   Phonetic     Combined    
--------------------------------------------------------------------------------------------------------------------
1    julius bear pvt limited ag                 100%         100%         100%        
2    julius bear private limited ag             92%          80%          88%         
3    julius bear pvt ltd                        87%          60%          77%         
4    julius bear private limited                90%          60%          79%         
5    julius bear limited ag                     84%          50%          72%         
6    julius bear ag                             73%          40%          62%         
7    julius bear corp                           68%          30%          54%         
8    julius bear private limited company        85%          70%          79%         
9    julius bear limited company                81%          50%          71%         
10   julius and bear pvt ltd                    88%          80%          85%         
...

✓ Results exported to: entity_search_julius_bear_pvt_limited_ag_hybrid.json
✓ Results exported to: entity_search_julius_bear_pvt_limited_ag_hybrid.csv
```

---

## 🔍 Detailed Mode Comparison

### OFFLINE Mode
```bash
python entity_search.py "Apple Inc" offline
```

**What it does:**
- Generates variations using 10+ rules
- Abbreviations: pvt→private, ltd→limited
- Case variations: Apple INC, apple inc
- Word reordering: Inc Apple
- Suffix removal: Apple (without Inc)
- Acronyms: AI

**Variations generated:** 8-15
**Time:** < 1 second
**API needed:** No ❌
**Quality:** Good ✓

**Use when:**
- Need instant results
- No internet connection
- API key unavailable
- Quick sanity check

---

### AI Mode
```bash
python entity_search.py "Apple Inc" ai
```

**What it does:**
- Uses Claude to generate creative variations
- Thinks about phonetic similarities
- Considers regional/cultural variations
- Generates domain-specific names
- More diverse and creative

**Variations generated:** 30-40
**Time:** 2-5 seconds
**API needed:** Yes ✅
**Quality:** Excellent ⭐⭐⭐

**Use when:**
- Need maximum variation coverage
- Have API key available
- Want creative/diverse results
- Can wait 2-5 seconds

---

### HYBRID Mode ⭐ RECOMMENDED
```bash
python entity_search.py "Apple Inc" hybrid
```

**What it does:**
- Step 1: Generate offline variations (fast)
- Step 2: Send to Claude for enhancement
- Step 3: Claude generates MORE based on initial set
- Step 4: Merge all + deduplicate
- Step 5: Score and rank

**Variations generated:** 40-60
**Time:** 2-5 seconds (same as AI, better results)
**API needed:** Yes ✅
**Quality:** Best ⭐⭐⭐⭐⭐

**Advantages:**
- Combines both approaches
- Gets baseline variations instantly (visible progress)
- AI enhancement based on existing patterns
- Better deduplication
- More diverse final set
- Same speed as AI-only

**Use when:**
- Production environment
- Want best possible results
- Have API key available
- Time not critical (2-5 seconds)

---

## 📊 Score Interpretation

All modes use the same scoring:

### Linguistic Score (60% weight)
- Text similarity using Levenshtein distance
- 0-100%

### Phonetic Score (40% weight)
- Sound-alike similarity using Soundex
- 0% or 100%

### Combined Score
```
Combined = (Linguistic × 0.6) + (Phonetic × 0.4)
```

### Score Categories
| Score | Category | Confidence |
|-------|----------|-----------|
| 80-100% | STRONG MATCH | High ✓✓✓ |
| 60-79% | MODERATE MATCH | Medium ✓✓ |
| 40-59% | WEAK MATCH | Low ✓ |
| 0-39% | NO MATCH | None |

---

## 💻 Real-World Examples

### Example 1: Quick Check (Offline)
```bash
# Fast check - no waiting
$ python entity_search.py "Microsoft Corp" offline

# Results in <1 second
Total variations: 12
Average score: 48%
```

### Example 2: Comprehensive Search (Hybrid)
```bash
# Get everything with AI enhancement
$ python entity_search.py "Microsoft Corp" hybrid

# Results in 2-5 seconds
Total variations: 45
Average score: 55%
```

### Example 3: Creative Variations (AI)
```bash
# Pure AI creativity
$ python entity_search.py "Microsoft Corp" ai

# Results in 2-5 seconds
Total variations: 38
Average score: 52%
```

---

## 📂 Output Files

For each run, you get:

### 1. Console Output
Pretty-printed table with top 25 variations

### 2. JSON File
`entity_search_<name>_<mode>.json`
```json
{
  "original_entity": "Julius bear pvt limited ag",
  "mode": "hybrid",
  "total_variations": 32,
  "average_score": 58,
  "top_match_score": 100,
  "variations": [
    {
      "variant": "julius bear pvt limited ag",
      "linguistic_score": 100,
      "phonetic_score": 100,
      "combined_score": 100
    },
    ...
  ]
}
```

### 3. CSV File
`entity_search_<name>_<mode>.csv`
```csv
variant,linguistic_score,phonetic_score,combined_score
julius bear pvt limited ag,100,100,100
julius bear private limited,92,80,86
...
```

---

## 🧠 How AI Enhancement Works in Hybrid Mode

**Step 1: Offline generates:**
```
- julius bear pvt limited ag
- julius bear private limited
- julius bear pvt ltd
- julius bear limited
- julius bear ag
- ...
```

**Step 2: AI sees these and thinks:**
"OK, this entity has:
- First names: Julius, Bear
- Legal terms: private/pvt, limited
- Suffix: ag

Let me generate more creative variations based on these patterns..."

**Step 3: AI generates additional:**
```
- julius and bear limited
- julius bear gesellschaft
- julius bear l.l.c.
- julius bear ventures
- bearjulius limited
- j. bear limited
- julius bear gmbh
- ...
```

**Step 4: Final merged list has both!**

---

## ⚙️ Environment Setup

### Required
```bash
pip install anthropic
```

### Optional (for AI/Hybrid modes)
```bash
export ANTHROPIC_API_KEY="sk-..."
```

### Check Setup
```bash
# Test offline mode (no API needed)
python entity_search.py "Test Company" offline

# If successful, test hybrid
python entity_search.py "Test Company" hybrid
```

---

## 🎯 Mode Selection Guide

```
Do you need results in <1 second?
├─ YES → Use OFFLINE mode
└─ NO → Continue...

Do you have ANTHROPIC_API_KEY set?
├─ NO → Use OFFLINE mode
└─ YES → Continue...

Do you want BEST results?
├─ YES → Use HYBRID mode ⭐ (RECOMMENDED)
└─ NO → Use AI mode (if you want pure AI)
```

---

## 📈 Performance Comparison

### Speed
```
Offline: <100ms (instant)
AI:      2-5 seconds
Hybrid:  2-5 seconds
```

### Variations Generated
```
Offline: 8-20 variations
AI:      30-40 variations
Hybrid:  40-60 variations (combined)
```

### Quality
```
Offline: ★★★☆☆ (Good, rule-based)
AI:      ★★★★★ (Excellent, creative)
Hybrid:  ★★★★★ (Best, combination)
```

### Cost
```
Offline: $0.00 (free)
AI:      ~$0.01 (per call)
Hybrid:  ~$0.01 (per call)
```

---

## 🚀 Production Recommendation

For production use, **always use HYBRID mode**:

```python
# In your Python code
import subprocess
import json

def get_entity_variations(entity_name):
    result = subprocess.run(
        ['python', 'entity_search.py', entity_name, 'hybrid'],
        capture_output=True,
        text=True
    )
    
    # Read the JSON output
    json_file = f"entity_search_{entity_name.replace(' ', '_')}_hybrid.json"
    with open(json_file) as f:
        data = json.load(f)
    
    return data['variations']

# Usage
variations = get_entity_variations("Your Company Name")
for var in variations:
    print(f"{var['variant']}: {var['combined_score']}%")
```

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ANTHROPIC_API_KEY not set` | `export ANTHROPIC_API_KEY="sk-..."` |
| Empty results | Check entity name is 3+ characters |
| Takes too long | Normal for AI/Hybrid (2-5 seconds) |
| Wrong file path | Check current directory |
| CSV not created | Run mode with write permissions |

---

## 📋 Command Reference

```bash
# Default (Hybrid mode)
python entity_search.py "Company Name"

# Specific modes
python entity_search.py "Company Name" offline
python entity_search.py "Company Name" ai
python entity_search.py "Company Name" hybrid

# With path
python /path/to/entity_search.py "Company Name"

# In production
python entity_search.py "$COMPANY_NAME" hybrid > results.txt
```

---

## ✨ Key Features

✅ **One script, three modes**
✅ **Hybrid = best of both worlds**
✅ **Works offline or with AI**
✅ **Automatic deduplication**
✅ **JSON + CSV export**
✅ **Scored results**
✅ **Production-ready**

---

## 🎓 Why Hybrid is Better

### Offline Alone
❌ Limited variations
❌ Misses creative patterns
✅ Fast
✅ No API needed

### AI Alone
✅ Creative variations
✅ Diverse results
❌ Takes 2-5 seconds
❌ Needs API key

### Hybrid (Best!)
✅ Baseline variations (fast visible progress)
✅ Creative AI enhancement
✅ Complete coverage
✅ Only 2-5 seconds (same as AI)
✅ Best deduplication
✅ Maximum diversity

---

## 📞 Quick Support

**High scores (>80%):** Likely same entity
**Mid scores (60-80%):** Probably same, verify manually
**Low scores (<40%):** Likely different entities

**For more details:** See USAGE.md

---

## 🎉 Summary

**One script. Three modes. Pick your speed/quality tradeoff:**

```
Need instant? → offline
Want best? → hybrid ⭐
Have time? → ai
```

**Recommended: Always use `hybrid` mode**

It gives you:
- Speed of offline (for immediate feedback)
- Quality of AI (for comprehensive results)
- All in one 2-5 second run

Happy entity searching! 🚀
