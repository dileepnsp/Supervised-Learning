#!/usr/bin/env python3
"""
Entity Comparison Tool
Compare 2 entities and get similarity scores

Usage:
    python compare_entities.py "Entity 1" "Entity 2"
    
Examples:
    python compare_entities.py "Julius bear pvt limited ag" "julius bear private limited"
    python compare_entities.py "Apple Inc" "Apple Corporation"
    python compare_entities.py "Smith & Associates" "Smith and Associates"
"""

import sys
import json
import re

# ============================================================================
# SIMILARITY ALGORITHMS
# ============================================================================

def soundex(text: str) -> str:
    """Generate Soundex code for phonetic similarity."""
    text = str(text).upper()
    text = re.sub(r'[^A-Z]', '', text)
    
    if not text:
        return ''
    
    first_letter = text[0]
    codes = {
        'B': '1', 'F': '1', 'P': '1', 'V': '1',
        'C': '2', 'G': '2', 'J': '2', 'K': '2', 'Q': '2', 'S': '2', 'X': '2', 'Z': '2',
        'D': '3', 'T': '3',
        'L': '4',
        'M': '5', 'N': '5',
        'R': '6'
    }
    
    code = first_letter
    prev_code = codes.get(first_letter, '0')
    
    for char in text[1:]:
        digit = codes.get(char, '0')
        if digit != '0' and digit != prev_code:
            code += digit
            if len(code) >= 4:
                break
            prev_code = digit
        elif digit == '0':
            prev_code = '0'
    
    return (code + '000')[:4]


def levenshtein_distance(s1: str, s2: str) -> int:
    """Calculate Levenshtein distance between two strings."""
    s1 = s1.lower()
    s2 = s2.lower()
    
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    
    if len(s2) == 0:
        return len(s1)
    
    previous_row = list(range(len(s2) + 1))
    
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]


def calculate_linguistic_similarity(original: str, variant: str) -> int:
    """Calculate linguistic similarity score (0-100)."""
    distance = levenshtein_distance(original, variant)
    max_length = max(len(original), len(variant))
    
    if max_length == 0:
        return 100
    
    similarity = (1 - distance / max_length) * 100
    return max(0, min(100, round(similarity)))


def calculate_phonetic_similarity(original: str, variant: str) -> int:
    """Calculate phonetic similarity score (0-100)."""
    s1 = soundex(original)
    s2 = soundex(variant)
    return 100 if s1 == s2 else 0


def calculate_combined_score(linguistic: int, phonetic: int) -> int:
    """Calculate combined score (60% linguistic + 40% phonetic)."""
    return round(linguistic * 0.6 + phonetic * 0.4)


# ============================================================================
# COMPARISON LOGIC
# ============================================================================

def compare_entities(entity1: str, entity2: str) -> dict:
    """Compare two entities and return similarity scores."""
    
    entity1 = entity1.strip()
    entity2 = entity2.strip()
    
    if not entity1 or not entity2:
        raise ValueError("Both entities must be non-empty")
    
    linguistic = calculate_linguistic_similarity(entity1, entity2)
    phonetic = calculate_phonetic_similarity(entity1, entity2)
    combined = calculate_combined_score(linguistic, phonetic)
    
    sx1 = soundex(entity1)
    sx2 = soundex(entity2)
    distance = levenshtein_distance(entity1, entity2)
    
    return {
        'entity1': entity1,
        'entity2': entity2,
        'linguistic_score': linguistic,
        'phonetic_score': phonetic,
        'combined_score': combined,
        'levenshtein_distance': distance,
        'soundex_entity1': sx1,
        'soundex_entity2': sx2,
        'is_phonetic_match': sx1 == sx2,
        'match_category': categorize_score(combined)
    }


def categorize_score(score: int) -> str:
    """Categorize the combined score."""
    if score >= 80:
        return "STRONG MATCH"
    elif score >= 60:
        return "MODERATE MATCH"
    elif score >= 40:
        return "WEAK MATCH"
    else:
        return "NO MATCH"


def display_comparison(result: dict):
    """Display comparison results in formatted output."""
    print("\n" + "="*70)
    print("ENTITY COMPARISON RESULT")
    print("="*70)
    
    print(f"\nEntity 1: {result['entity1']}")
    print(f"Entity 2: {result['entity2']}")
    
    print(f"\n{'-'*70}")
    print("SIMILARITY SCORES:")
    print(f"{'-'*70}")
    
    print(f"Linguistic Score:  {result['linguistic_score']:>3}%  (character-level similarity)")
    print(f"Phonetic Score:    {result['phonetic_score']:>3}%  (sounds-like similarity)")
    print(f"Combined Score:    {result['combined_score']:>3}%  (weighted average)")
    
    print(f"\n{'-'*70}")
    print("PHONETIC ANALYSIS:")
    print(f"{'-'*70}")
    
    print(f"Entity 1 Soundex:   {result['soundex_entity1']}")
    print(f"Entity 2 Soundex:   {result['soundex_entity2']}")
    print(f"Soundex Match:      {'YES ✓' if result['is_phonetic_match'] else 'NO ✗'}")
    
    print(f"\n{'-'*70}")
    print("LINGUISTIC ANALYSIS:")
    print(f"{'-'*70}")
    
    print(f"Levenshtein Distance: {result['levenshtein_distance']} character edits needed")
    
    print(f"\n{'-'*70}")
    print("VERDICT:")
    print(f"{'-'*70}")
    
    print(f"Match Category: {result['match_category']}")
    
    if result['combined_score'] >= 80:
        print("→ These are likely the SAME entity (use with high confidence)")
    elif result['combined_score'] >= 60:
        print("→ These are likely the SAME entity (verify manually)")
    elif result['combined_score'] >= 40:
        print("→ These entities might be related (check manually)")
    else:
        print("→ These are likely DIFFERENT entities")
    
    print("\n" + "="*70)


def export_json(result: dict, filename: str):
    """Export comparison result to JSON."""
    with open(filename, 'w') as f:
        json.dump(result, f, indent=2)
    print(f"✓ Result exported to: {filename}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Main entry point."""
    if len(sys.argv) < 3:
        print("Usage: python compare_entities.py <entity1> <entity2>")
        print("\nExamples:")
        print("  python compare_entities.py 'Julius bear pvt limited ag' 'julius bear private limited'")
        print("  python compare_entities.py 'Apple Inc' 'Apple Corporation'")
        print("  python compare_entities.py 'Smith & Associates' 'Smith and Associates'")
        sys.exit(1)
    
    entity1 = sys.argv[1]
    entity2 = sys.argv[2]
    
    try:
        # Compare entities
        result = compare_entities(entity1, entity2)
        
        # Display results
        display_comparison(result)
        
        # Export to JSON
        filename = "comparison_result.json"
        export_json(result, filename)
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
