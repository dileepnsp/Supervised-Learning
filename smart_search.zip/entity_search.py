#!/usr/bin/env python3
"""
Entity Name Variations Generator - Unified Mode
Combines offline (fast) + AI (creative) for best results

Usage:
    python entity_search.py "Entity Name"              # Auto (offline + AI if available)
    python entity_search.py "Entity Name" offline      # Offline only
    python entity_search.py "Entity Name" ai           # AI only
    python entity_search.py "Entity Name" hybrid       # Offline + AI (recommended)

The 'hybrid' mode:
    1. Generates base variations offline (fast)
    2. Sends those to Claude AI (creative enhancement)
    3. Claude adds more variations based on the initial set
    4. Returns merged+deduplicated final list
"""

import sys
import json
import re
from typing import List, Dict, Set
import anthropic

# ============================================================================
# SIMILARITY ALGORITHMS
# ============================================================================

def soundex(text: str) -> str:
    """Generate Soundex code for phonetic similarity."""
    text = str(text).upper()
    text = re.sub(r'[^A-Z]', '', text)
    
    if not text:
        return ''
    
    first_letter = text[0]
    codes = {
        'B': '1', 'F': '1', 'P': '1', 'V': '1',
        'C': '2', 'G': '2', 'J': '2', 'K': '2', 'Q': '2', 'S': '2', 'X': '2', 'Z': '2',
        'D': '3', 'T': '3',
        'L': '4',
        'M': '5', 'N': '5',
        'R': '6'
    }
    
    code = first_letter
    prev_code = codes.get(first_letter, '0')
    
    for char in text[1:]:
        digit = codes.get(char, '0')
        if digit != '0' and digit != prev_code:
            code += digit
            if len(code) >= 4:
                break
            prev_code = digit
        elif digit == '0':
            prev_code = '0'
    
    return (code + '000')[:4]


def levenshtein_distance(s1: str, s2: str) -> int:
    """Calculate Levenshtein distance between two strings."""
    s1 = s1.lower()
    s2 = s2.lower()
    
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    
    if len(s2) == 0:
        return len(s1)
    
    previous_row = list(range(len(s2) + 1))
    
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]


def calculate_linguistic_similarity(original: str, variant: str) -> int:
    """Calculate linguistic similarity score (0-100)."""
    distance = levenshtein_distance(original, variant)
    max_length = max(len(original), len(variant))
    
    if max_length == 0:
        return 100
    
    similarity = (1 - distance / max_length) * 100
    return max(0, min(100, round(similarity)))


def calculate_phonetic_similarity(original: str, variant: str) -> int:
    """Calculate phonetic similarity score (0-100)."""
    s1 = soundex(original)
    s2 = soundex(variant)
    return 100 if s1 == s2 else 0


def calculate_combined_score(linguistic: int, phonetic: int) -> int:
    """Calculate combined score (60% linguistic + 40% phonetic)."""
    return round(linguistic * 0.6 + phonetic * 0.4)


# ============================================================================
# OFFLINE MODE
# ============================================================================

def generate_variations_offline(entity_name: str) -> List[str]:
    """Generate base variations using rule-based approach."""
    variations = set()
    original = entity_name.strip()
    variations.add(original)
    
    # 1. Case variations
    variations.add(original.lower())
    variations.add(original.upper())
    variations.add(original.title())
    
    # 2. Common abbreviation mappings
    abbreviations = {
        'private': ['pvt', 'priv'],
        'limited': ['ltd', 'lim'],
        'incorporated': ['inc', 'incorp'],
        'corporation': ['corp', 'co'],
        'company': ['co', 'coy'],
        'and': ['&', '+'],
        'actiengesellschaft': ['ag', 'a.g.'],
        'gesellschaft mit beschraenkter haftung': ['gmbh', 'g.m.b.h.'],
    }
    
    text_lower = original.lower()
    
    for full, abbrevs in abbreviations.items():
        if full in text_lower:
            for abbrev in abbrevs:
                variant = re.sub(r'\b' + full + r'\b', abbrev, text_lower, flags=re.IGNORECASE)
                variations.add(variant)
                variant_with_dots = re.sub(r'\b' + abbrev + r'\b', '.'.join(abbrev) + '.', variant)
                variations.add(variant_with_dots)
    
    # 3. Remove/add periods
    with_dots = re.sub(r'([a-z])([\s])', r'\1.\2', original.lower())
    variations.add(with_dots)
    without_dots = original.replace('.', '').strip()
    variations.add(without_dots)
    
    # 4. Remove special characters
    no_special = re.sub(r'[&()-]', ' ', original)
    no_special = re.sub(r'\s+', ' ', no_special).strip()
    variations.add(no_special)
    
    # 5. Word permutations
    words = original.split()
    if len(words) > 1:
        variations.add(' '.join(reversed(words)))
        if len(words) >= 2:
            variations.add(words[0] + ' ' + words[-1])
            variations.add(' '.join(words[:2]))
            variations.add(' '.join(words[-2:]))
    
    # 6. Acronym
    first_letters = ''.join([w[0].upper() for w in words if w])
    if len(first_letters) > 1:
        variations.add(first_letters)
        variations.add(first_letters.lower())
    
    # 7. Suffixes removal
    suffixes = ['inc', 'ltd', 'llc', 'corp', 'ag', 'ag.', 'pvt', 'co']
    for suffix in suffixes:
        if text_lower.endswith(suffix):
            variant = re.sub(r'\s*' + suffix + r'\s*$', '', text_lower)
            variations.add(variant.strip())
    
    # 8. Spelling variations
    spelling_variations = {
        'co': ['co.', 'co', 'corp'],
        'and': ['&', 'and', '+'],
        'centre': ['center', 'centre'],
        'organisation': ['organization', 'organisation'],
    }
    
    for variant_word, spellings in spelling_variations.items():
        for spelling in spellings:
            if variant_word in text_lower:
                for alt_spelling in spellings:
                    if alt_spelling != variant_word:
                        var = text_lower.replace(variant_word, alt_spelling)
                        variations.add(var)
    
    # 9. Normalize spaces
    normalized = re.sub(r'\s+', ' ', original).strip()
    variations.add(normalized)
    
    # 10. Replace & and and
    if '&' in original:
        variations.add(original.replace('&', 'and'))
    if ' and ' in original.lower():
        variations.add(re.sub(r'\band\b', '&', original, flags=re.IGNORECASE))
    
    variations = [v for v in variations if v and v.strip()]
    
    return sorted(list(variations))


# ============================================================================
# AI MODE - ENHANCED (takes offline variations as input)
# ============================================================================

def generate_variations_ai_enhanced(entity_name: str, offline_variations: List[str]) -> List[str]:
    """
    Use Claude to generate additional variations based on offline results.
    Takes offline variations and asks Claude to expand on them.
    """
    client = anthropic.Anthropic()
    
    # Create a prompt that builds on the offline variations
    variations_str = '\n'.join([f"  - {v}" for v in offline_variations[:10]])  # Show first 10
    
    prompt = f"""Given this entity name: "{entity_name}"

And these already-generated base variations:
{variations_str}
...

Now generate 20 MORE variations that are different/creative. Consider:
- Phonetic variations (how it might sound in different accents)
- Common misspellings in your region
- Alternative industry terminology
- Abbreviation combinations
- Expanded/contracted forms
- Cultural variations
- Domain-specific names

Return ONLY a JSON array of strings, nothing else.
Example: ["variation1", "variation2", ...]"""

    print(f"  Enhancing with AI...", file=sys.stderr)
    
    message = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=1500,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    
    # Extract JSON array
    json_match = re.search(r'\[[\s\S]*\]', response_text)
    if not json_match:
        print("  Warning: Could not parse AI variations", file=sys.stderr)
        return []
    
    try:
        variations = json.loads(json_match.group())
        return [str(v).strip() for v in variations if v]
    except json.JSONDecodeError:
        print("  Warning: Invalid JSON from AI", file=sys.stderr)
        return []


# ============================================================================
# HYBRID MODE (combining both)
# ============================================================================

def generate_variations_hybrid(entity_name: str) -> List[str]:
    """
    Hybrid mode: Offline first, then AI enhancement.
    1. Generate offline variations (fast)
    2. Send to AI for enhancement (creative)
    3. Return merged list
    """
    print(f"[1/3] Generating offline variations...", file=sys.stderr)
    offline_vars = generate_variations_offline(entity_name)
    print(f"      Generated {len(offline_vars)} offline variations", file=sys.stderr)
    
    print(f"[2/3] Enhancing with AI...", file=sys.stderr)
    try:
        ai_vars = generate_variations_ai_enhanced(entity_name, offline_vars)
        print(f"      Generated {len(ai_vars)} AI variations", file=sys.stderr)
    except Exception as e:
        print(f"      AI enhancement failed: {e}", file=sys.stderr)
        ai_vars = []
    
    # Merge and deduplicate (case-insensitive)
    print(f"[3/3] Merging and deduplicating...", file=sys.stderr)
    seen = set()
    merged = []
    
    for var in offline_vars + ai_vars:
        var_lower = var.lower()
        if var_lower not in seen:
            seen.add(var_lower)
            merged.append(var)
    
    print(f"      Final count: {len(merged)} unique variations", file=sys.stderr)
    
    return sorted(merged)


# ============================================================================
# AI ONLY MODE
# ============================================================================

def generate_variations_ai_only(entity_name: str) -> List[str]:
    """Generate variations using AI only (no offline mode)."""
    client = anthropic.Anthropic()
    
    prompt = f"""Generate 40 realistic variations of this entity name: "{entity_name}"

Include:
- Abbreviations (pvt→private, ltd→limited, ag→aktiengesellschaft)
- Different orderings
- Alternative spellings
- Common misspellings
- Acronyms
- Expanded forms
- With/without suffixes
- Different cases
- Regional variations
- Phonetic variations

Return ONLY a JSON array of strings, nothing else.
Example: ["variation1", "variation2", ...]"""

    print(f"Generating variations using Claude AI...", file=sys.stderr)
    
    message = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=2000,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    
    json_match = re.search(r'\[[\s\S]*\]', response_text)
    if not json_match:
        raise ValueError("Could not parse variations from Claude response")
    
    variations = json.loads(json_match.group())
    return sorted(list(set([str(v).strip() for v in variations if v])))


# ============================================================================
# SCORING AND OUTPUT
# ============================================================================

def score_variations(original: str, variations: List[str]) -> List[Dict]:
    """Score all variations against the original."""
    results = []
    
    for variant in variations:
        if variant.lower() == original.lower():
            linguistic = 100
            phonetic = 100
        else:
            linguistic = calculate_linguistic_similarity(original, variant)
            phonetic = calculate_phonetic_similarity(original, variant)
        
        combined = calculate_combined_score(linguistic, phonetic)
        
        results.append({
            'variant': variant,
            'linguistic_score': linguistic,
            'phonetic_score': phonetic,
            'combined_score': combined
        })
    
    results.sort(key=lambda x: x['combined_score'], reverse=True)
    
    return results


def display_results(original: str, results: List[Dict], mode: str, limit: int = 25):
    """Display results in formatted table."""
    print("\n" + "="*110)
    print(f"Entity Name Variations: {original}")
    print(f"Mode: {mode.upper()}")
    print("="*110)
    print(f"\nTotal variations: {len(results)}")
    print(f"Average score: {round(sum(r['combined_score'] for r in results) / len(results))}%")
    print(f"Top match: {results[0]['combined_score']}%\n")
    
    print(f"{'#':<4} {'Variant':<50} {'Linguistic':<12} {'Phonetic':<12} {'Combined':<12}")
    print("-"*110)
    
    items = results[:limit] if limit else results
    for i, item in enumerate(items, 1):
        ling = f"{item['linguistic_score']}%"
        phon = f"{item['phonetic_score']}%"
        comb = f"{item['combined_score']}%"
        print(f"{i:<4} {item['variant']:<50} {ling:<12} {phon:<12} {comb:<12}")
    
    if limit and len(results) > limit:
        print(f"\n... and {len(results) - limit} more variations (see JSON file for complete list)")


def export_json(original: str, results: List[Dict], mode: str, filename: str):
    """Export results to JSON."""
    data = {
        'original_entity': original,
        'mode': mode,
        'total_variations': len(results),
        'average_score': round(sum(r['combined_score'] for r in results) / len(results)) if results else 0,
        'top_match_score': results[0]['combined_score'] if results else 0,
        'variations': results
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"✓ Results exported to: {filename}")


def export_csv(results: List[Dict], filename: str):
    """Export results to CSV."""
    import csv
    
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['variant', 'linguistic_score', 'phonetic_score', 'combined_score'])
        writer.writeheader()
        writer.writerows(results)
    
    print(f"✓ Results exported to: {filename}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python entity_search.py <entity_name> [offline|ai|hybrid]")
        print("\nModes:")
        print("  offline  - Fast rule-based variations (instant)")
        print("  ai       - Creative AI-generated variations (2-5 seconds)")
        print("  hybrid   - Offline + AI enhancement (RECOMMENDED) (2-5 seconds)")
        print("\nExamples:")
        print("  python entity_search.py 'Julius bear pvt limited ag'")
        print("  python entity_search.py 'Julius bear pvt limited ag' offline")
        print("  python entity_search.py 'Julius bear pvt limited ag' ai")
        print("  python entity_search.py 'Julius bear pvt limited ag' hybrid")
        sys.exit(1)
    
    entity_name = sys.argv[1].strip()
    mode = sys.argv[2].lower() if len(sys.argv) > 2 else 'hybrid'
    
    if not entity_name:
        print("Error: Entity name cannot be empty")
        sys.exit(1)
    
    if mode not in ['offline', 'ai', 'hybrid']:
        print(f"Error: Mode must be 'offline', 'ai', or 'hybrid', got '{mode}'")
        sys.exit(1)
    
    # Generate variations based on mode
    try:
        if mode == 'offline':
            print(f"Generating variations (OFFLINE mode)...", file=sys.stderr)
            variations = generate_variations_offline(entity_name)
        elif mode == 'ai':
            print(f"Generating variations (AI mode)...", file=sys.stderr)
            variations = generate_variations_ai_only(entity_name)
        else:  # hybrid
            print(f"Generating variations (HYBRID mode)...", file=sys.stderr)
            variations = generate_variations_hybrid(entity_name)
    except Exception as e:
        print(f"Error generating variations: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Score variations
    print(f"Scoring {len(variations)} variations...", file=sys.stderr)
    results = score_variations(entity_name, variations)
    
    # Display results
    display_results(entity_name, results, mode, limit=25)
    
    # Export results
    safe_name = entity_name.replace(' ', '_').replace('/', '_').replace('\\', '_')
    json_file = f"entity_search_{safe_name}_{mode}.json"
    csv_file = f"entity_search_{safe_name}_{mode}.csv"
    
    try:
        export_json(entity_name, results, mode, json_file)
        export_csv(results, csv_file)
    except Exception as e:
        print(f"Export error: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
